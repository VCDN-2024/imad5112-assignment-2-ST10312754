package com.example.imadassignment2

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.lang.ref.Cleaner

class Start : AppCompatActivity() {
    private lateinit var PetImageView: ImageView
   private lateinit var btnfeed: Button
    private lateinit var btnplay: Button
    private lateinit var btnclean: Button
    private lateinit var edtHunger: EditText
    private lateinit var edtClean : EditText
    private lateinit var edtHappy : EditText
    private lateinit var statusTextView: TextView

    // Pet status variables
    private var health: Int = 100
    private var hunger: Int = 0
    private var cleanliness: Int = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        statusTextView = findViewById(R.id.statusTextView)
        PetImageView = findViewById(R.id.PetImageView)
        btnfeed = findViewById<Button>(R.id.btnfeed)
        btnplay = findViewById<Button>(R.id.btnplay)
        btnclean = findViewById<Button>(R.id.btnclean)
        edtHunger = findViewById<EditText>(R.id.edtHunger)
        edtClean = findViewById<EditText>(R.id.edtClean)
        edtHappy = findViewById<EditText>(R.id.edtHappy)
    }



        fun onFeedClicked(view: View) {
            PetImageView.setImageResource(R.drawable.hungry)
            updateStatus("Fed the pet. Hunger decreased.")
        }

        fun onCleanClicked(view: View) {
            PetImageView.setImageResource(R.drawable.dirty)
            updateStatus("Cleaned the pet. Cleanliness increased.")
        }

        fun onPlayClicked(view: View) {
            PetImageView.setImageResource(R.drawable.happy)
            updateStatus("Played with the pet.")
        }

        private fun updateStatus(message: String) {
            hunger += 10
            cleanliness -= 10
            if (hunger > 100) hunger = 100
            if (cleanliness < 0) cleanliness = 0

            statusTextView.text = "Health: $health, Hunger: $hunger, Cleanliness: $cleanliness\n$message"
        }

}